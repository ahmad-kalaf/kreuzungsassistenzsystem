package meinprojekt;

public class Hauptklasse {

	public static void main(String[] args) {

		KreuzungsUI ui = new KreuzungsUI();

	}

}

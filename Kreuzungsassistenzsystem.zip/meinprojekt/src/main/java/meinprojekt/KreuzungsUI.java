package meinprojekt;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class KreuzungsUI {
	private JFrame frame;
	private JPanel panel;
	private JLabel label;
	private String A, B, C, D;
	private PrologConnectService prologConnection;
	private String ergebnis;
	private String kreuzungsart;
	private String resA, resB, resC, resD;
	JLabel labA, labB, labC, labD;

	public KreuzungsUI() {
		A = "kein";
		B = "kein";
		C = "kein";
		D = "kein";
		resA = "0";
		resB = "0";
		resC = "0";
		resD = "0";
		ergebnis = "";
		kreuzungsart = "ohne";
		prologConnection = new PrologConnectService();

		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize(new Dimension(500, 500));
		frame.setLocationRelativeTo(null);

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panel.setLayout(new GridLayout(2, 1, 0, 100));

		JPanel menuPanel = new JPanel();
		// Platzhalter
		JPanel spacer1 = new JPanel();
		spacer1.setPreferredSize(new Dimension(120, 40));
		spacer1.setVisible(false);
		JPanel spacer2 = new JPanel();
		spacer2.setPreferredSize(new Dimension(120, 40));
		spacer2.setVisible(false);
		JPanel spacer3 = new JPanel();
		spacer3.setPreferredSize(new Dimension(120, 40));
		spacer3.setVisible(false);
		JPanel spacer4 = new JPanel();
		spacer4.setPreferredSize(new Dimension(120, 40));
		spacer4.setVisible(false);
		JPanel spacer5 = new JPanel();
		spacer5.setPreferredSize(new Dimension(120, 40));
		spacer5.setVisible(false);

		menuPanel.setLayout(new GridLayout(3, 3, 50, 50));
		String[] richtungswuensche = { "kein", "rechts", "geradeaus", "links" };
		JComboBox<String> menuA = new JComboBox<String>(richtungswuensche);
		menuA.setPreferredSize(new Dimension(120, 40));
		menuA.setFocusable(false);
		menuA.addActionListener(arg -> {
			setA((String) menuA.getSelectedItem());
			reagiereAufAenderung();
		});

		JPanel panA = new JPanel();
		panA.setLayout(new BoxLayout(panA, BoxLayout.X_AXIS));
		labA = new JLabel(resA + "  ");
		labA.setFont(new Font("SansSerif", Font.PLAIN, 10));
		panA.add(labA);
		panA.add(menuA);

		JComboBox<String> menuB = new JComboBox<String>(richtungswuensche);
		menuB.setPreferredSize(new Dimension(120, 40));
		menuB.setFocusable(false);
		menuB.addActionListener(arg -> {
			setB((String) menuB.getSelectedItem());
			reagiereAufAenderung();
		});

		JPanel panB = new JPanel();
		panB.setLayout(new BoxLayout(panB, BoxLayout.X_AXIS));
		labB = new JLabel(resD + "  ");
		labB.setFont(new Font("SansSerif", Font.PLAIN, 10));
		panB.add(labB);
		panB.add(menuB);

		JComboBox<String> menuC = new JComboBox<String>(richtungswuensche);
		menuC.setPreferredSize(new Dimension(120, 40));
		menuC.setFocusable(false);
		menuC.addActionListener(arg -> {
			setC((String) menuC.getSelectedItem());
			reagiereAufAenderung();
		});

		JPanel panC = new JPanel();
		panC.setLayout(new BoxLayout(panC, BoxLayout.X_AXIS));
		labC = new JLabel("  " + resC);
		labC.setFont(new Font("SansSerif", Font.PLAIN, 10));
		panC.add(menuC);
		panC.add(labC);

		JComboBox<String> menuD = new JComboBox<String>(richtungswuensche);
		menuD.setPreferredSize(new Dimension(120, 40));
		menuD.setFocusable(false);
		menuD.addActionListener(arg -> {
			setD((String) menuD.getSelectedItem());
			reagiereAufAenderung();
		});

		JPanel panD = new JPanel();
		panD.setLayout(new BoxLayout(panD, BoxLayout.X_AXIS));
		labD = new JLabel(resD + "  ");
		labD.setFont(new Font("SansSerif", Font.PLAIN, 10));
		panD.add(labD);
		panD.add(menuD);

		menuPanel.add(spacer1);
//		menuPanel.add(menuB);
		menuPanel.add(panB);
		menuPanel.add(spacer2);
//		menuPanel.add(menuA);
		menuPanel.add(panA);
		menuPanel.add(spacer3);
//		menuPanel.add(menuC);
		menuPanel.add(panC);
		menuPanel.add(spacer4);
//		menuPanel.add(menuD);
		menuPanel.add(panD);
		menuPanel.add(spacer5);

//		setKreuzungToOhne(spacer1, spacer2, spacer3, spacer4, spacer5);

		String[] kreuzungsarten = { "ohne", "mitOU", "mitOR" };
		JComboBox<String> menuKreuzungsart = new JComboBox<String>(kreuzungsarten);
		menuKreuzungsart.setPreferredSize(new Dimension(120, 40));
		menuKreuzungsart.setFocusable(false);
		menuKreuzungsart.addActionListener(arg -> {
			setKreuzungsart((String) menuKreuzungsart.getSelectedItem());
			reagiereAufAenderung();
		});

//		JButton button = new JButton("\u25B6");
//		button.setFocusable(false);
		JPanel textPanel = new JPanel();
		textPanel.setLayout(new FlowLayout());
		ergebnis = prologConnection.fuehrePredikatAus("ohne", getA(), getB(), getC(), getD());
		label = new JLabel("Reihenfolge = " + ergebnis);

//		button.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent arg0) {
//				reagiereAufAenderung();
//			}
//		});

		JPanel spacer6 = new JPanel();
		spacer6.setPreferredSize(new Dimension(20, 10));
		JPanel spacer7 = new JPanel();
		spacer7.setPreferredSize(new Dimension(20, 10));

		textPanel.add(menuKreuzungsart);
		textPanel.add(spacer6);
//		textPanel.add(button);
		textPanel.add(spacer7);
		textPanel.add(label);

		panel.add(menuPanel);
		panel.add(textPanel);

		frame.add(panel);
		frame.setVisible(true);
	}

	private void reagiereAufAenderung() {
		ergebnis = prologConnection.fuehrePredikatAus(getKreuzungsart(), getA(), getB(), getC(), getD());
		label.setText("Reihenfolge = " + ergebnis);
		labA.setText(String.valueOf(ergebnis.charAt(1)) + "  ");
		labB.setText(String.valueOf(ergebnis.charAt(4)) + "  ");
		labC.setText("  " + String.valueOf(ergebnis.charAt(7)));
		labD.setText(String.valueOf(ergebnis.charAt(10)) + "  ");
	}

//	private void setKreuzungToOhne(JPanel topleft, JPanel topright, JPanel centercenter, JPanel bottomleft,
//			JPanel bottomright) {
//		
//	}
//
//	private void setKreuzungToMitOU() {
//
//	}
//
//	private void setKreuzungToMitOR() {
//
//	}

	public String getKreuzungsart() {
		return kreuzungsart;
	}

	public void setKreuzungsart(String kreuzungsart) {
		this.kreuzungsart = kreuzungsart;
	}

	public String getA() {
		return A;
	}

	public void setA(String a) {
		A = a;
	}

	public String getB() {
		return B;
	}

	public void setB(String b) {
		B = b;
	}

	public String getC() {
		return C;
	}

	public void setC(String c) {
		C = c;
	}

	public String getD() {
		return D;
	}

	public void setD(String d) {
		D = d;
	}
}

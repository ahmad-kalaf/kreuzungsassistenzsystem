package meinprojekt;

import java.io.*;

import org.projog.api.Projog;
import org.projog.api.QueryResult;

public class PrologConnectService {
	private Projog projog;

	public PrologConnectService() {
		// Create a new Projog instance.
		projog = new Projog();

		// Load Prolog facts and rules from a file located in the resources directory.
		try (InputStream is = getClass().getClassLoader().getResourceAsStream("kreuzung.pl");
				Reader reader = new BufferedReader(new InputStreamReader(is))) {
			if (is != null) {
				// Now consult the Prolog file using the reader.
				projog.consultReader(reader);
			} else {
				throw new FileNotFoundException("Resource 'kreuzung.pl' not found in classpath");
			}
		} catch (IOException e) {
			e.printStackTrace();
			// Handle the exception as appropriate in your application
		}
	}

	public String fuehrePredikatAus(String kreuzungsart, String a, String b, String c, String d) {
		String predikat = "vorfahrt(" + kreuzungsart + ", [" + a + ", " + b + ", " + c + ", " + d + "], R).";
		// Execute a query and and get the first result.
		QueryResult r3 = projog.executeQuery(predikat);
		r3.next();
		String result = projog.formatTerm(r3.getTerm("R"));
		char A = result.charAt(1);
		char B = result.charAt(3);
		char C = result.charAt(5);
		char D = result.charAt(7);
		return "[" + A + ", " + B + ", " + C + ", " + D + "]";
	}
}
